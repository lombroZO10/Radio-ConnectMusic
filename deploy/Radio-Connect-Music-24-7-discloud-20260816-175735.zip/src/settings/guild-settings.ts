import { z } from 'zod';

export const guildSettingsSchema = z.object({
  guildId: z.string().regex(/^\d+$/),
  voiceChannelId: z.string().regex(/^\d+$/),
});

export const guildSettingsFileSchema = z.object({
  version: z.literal(1),
  guilds: z.array(guildSettingsSchema),
});

export type GuildSettings = z.infer<typeof guildSettingsSchema>;

export interface GuildSettingsRepository {
  get(guildId: string): GuildSettings | undefined;
  list(): readonly GuildSettings[];
  setVoiceChannel(guildId: string, voiceChannelId: string): void;
}
