import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

import {
  guildSettingsFileSchema,
  type GuildSettings,
  type GuildSettingsRepository,
} from './guild-settings.js';

export class JsonGuildSettingsRepository implements GuildSettingsRepository {
  readonly #filePath: string;
  readonly #settings = new Map<string, GuildSettings>();

  constructor(filePath = resolve(process.cwd(), 'data', 'guild-settings.json')) {
    this.#filePath = filePath;
    this.#load();
  }

  get(guildId: string): GuildSettings | undefined {
    return this.#settings.get(guildId);
  }

  list(): readonly GuildSettings[] {
    return [...this.#settings.values()];
  }

  setVoiceChannel(guildId: string, voiceChannelId: string): void {
    this.#settings.set(guildId, { guildId, voiceChannelId });
    this.#save();
  }

  #load(): void {
    if (!existsSync(this.#filePath)) return;
    const raw: unknown = JSON.parse(readFileSync(this.#filePath, 'utf8'));
    const file = guildSettingsFileSchema.parse(raw);
    for (const settings of file.guilds) this.#settings.set(settings.guildId, settings);
  }

  #save(): void {
    mkdirSync(dirname(this.#filePath), { recursive: true });
    const payload = guildSettingsFileSchema.parse({ version: 1, guilds: this.list() });
    const temporaryPath = `${this.#filePath}.${String(process.pid)}.tmp`;
    writeFileSync(temporaryPath, `${JSON.stringify(payload, null, 2)}\n`, {
      encoding: 'utf8',
      mode: 0o600,
    });
    renameSync(temporaryPath, this.#filePath);
  }
}
