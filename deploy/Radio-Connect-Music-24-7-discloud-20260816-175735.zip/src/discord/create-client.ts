import { ActivityType, Client, Collection, Events, GatewayIntentBits } from 'discord.js';

import { config } from '../config/index.js';
import type { RadioManager } from '../radio/radio-manager.js';
import type { GuildSettingsRepository } from '../settings/guild-settings.js';
import { logger } from '../shared/logger.js';
import type { DiscordCommand } from './command.js';
import type { ComponentHandler } from './component.js';
import { restoreConfiguredVoiceChannels } from './restore-voice-channels.js';

export function createDiscordClient(
  commands: readonly DiscordCommand[],
  componentHandlers: readonly ComponentHandler[],
  radio: RadioManager,
  settings: GuildSettingsRepository,
): Client {
  const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildVoiceStates],
  });
  const commandMap = new Collection<string, DiscordCommand>();
  for (const command of commands) commandMap.set(command.data.name, command);

  client.once(Events.ClientReady, async (readyClient) => {
    readyClient.user.setActivity(config.discord.activity, { type: ActivityType.Listening });
    logger.info(
      { user: readyClient.user.tag, guilds: readyClient.guilds.cache.size },
      'Bot conectado ao Discord',
    );
    await restoreConfiguredVoiceChannels(readyClient, settings, radio, logger);
  });

  client.on(Events.InteractionCreate, async (interaction) => {
    try {
      if (interaction.isAutocomplete()) {
        await commandMap.get(interaction.commandName)?.autocomplete?.(interaction);
        return;
      }
      if (interaction.isMessageComponent()) {
        const handler = componentHandlers.find((item) => item.canHandle(interaction.customId));
        if (handler) await handler.execute(interaction);
        return;
      }
      if (!interaction.isChatInputCommand()) return;
      const command = commandMap.get(interaction.commandName);
      if (!command) return;
      await command.execute({ interaction });
    } catch (error) {
      logger.error(
        {
          err: error,
          interactionId: interaction.id,
          command: 'commandName' in interaction ? interaction.commandName : undefined,
        },
        'Falha ao executar interação',
      );
      if (!interaction.isRepliable()) return;
      const message = {
        content: 'Ocorreu um erro ao executar esse comando.',
        ephemeral: true,
      } as const;
      if (interaction.replied || interaction.deferred) await interaction.followUp(message);
      else await interaction.reply(message);
    }
  });

  const shutdown = async (signal: string) => {
    logger.info({ signal }, 'Encerrando aplicação');
    radio.stopAll();
    await client.destroy();
  };
  process.once('SIGINT', () => {
    void shutdown('SIGINT');
  });
  process.once('SIGTERM', () => {
    void shutdown('SIGTERM');
  });

  return client;
}
