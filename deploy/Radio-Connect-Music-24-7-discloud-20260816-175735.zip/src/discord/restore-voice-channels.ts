import { ChannelType, type Client } from 'discord.js';

import type { RadioManager } from '../radio/radio-manager.js';
import type { GuildSettingsRepository } from '../settings/guild-settings.js';
import type { logger as rootLogger } from '../shared/logger.js';

type Logger = typeof rootLogger;

export async function restoreConfiguredVoiceChannels(
  client: Client<true>,
  settings: GuildSettingsRepository,
  radio: RadioManager,
  logger: Logger,
): Promise<void> {
  for (const guildSettings of settings.list()) {
    try {
      const guild = await client.guilds.fetch(guildSettings.guildId);
      const channel = await guild.channels.fetch(guildSettings.voiceChannelId);
      if (channel?.type !== ChannelType.GuildVoice) {
        logger.warn(guildSettings, 'Canal de voz configurado não existe mais');
        continue;
      }
      await radio.connect(channel);
      logger.info(guildSettings, 'Canal de voz permanente restaurado');
    } catch (error) {
      logger.error({ err: error, ...guildSettings }, 'Falha ao restaurar canal de voz permanente');
    }
  }
}
