import {
  AudioPlayerStatus,
  NoSubscriberBehavior,
  VoiceConnectionStatus,
  createAudioPlayer,
  createAudioResource,
  entersState,
  joinVoiceChannel,
  type AudioPlayer,
  type VoiceConnection,
} from '@discordjs/voice';
import type { VoiceBasedChannel } from 'discord.js';

import type { RadioConfig, Station } from '../config/schemas.js';
import type { logger as rootLogger } from '../shared/logger.js';

type Logger = typeof rootLogger;

export interface SessionSnapshot {
  station: Station;
  channelId: string;
}

export class RadioSession {
  readonly #settings: RadioConfig['playback'];
  readonly #logger: Logger;
  readonly #player: AudioPlayer;
  #connection: VoiceConnection | undefined;
  #station: Station | undefined;
  #channelId: string | undefined;
  #reconnectAttempts = 0;
  #reconnectTimer: NodeJS.Timeout | undefined;
  #stoppedIntentionally = false;

  constructor(guildId: string, settings: RadioConfig['playback'], logger: Logger) {
    this.#settings = settings;
    this.#logger = logger.child({ guildId });
    this.#player = createAudioPlayer({
      behaviors: { noSubscriber: NoSubscriberBehavior.Play },
    });

    this.#player.on('error', (error) => {
      this.#logger.error({ err: error, stationId: this.#station?.id }, 'Falha no áudio');
      this.#scheduleReconnect();
    });
    this.#player.on(AudioPlayerStatus.Playing, () => {
      this.#reconnectAttempts = 0;
      this.#logger.info({ stationId: this.#station?.id }, 'Transmissão iniciada');
    });
    this.#player.on(AudioPlayerStatus.Idle, () => {
      if (!this.#stoppedIntentionally && this.#station) this.#scheduleReconnect();
    });
  }

  async connect(channel: VoiceBasedChannel): Promise<void> {
    this.#clearReconnectTimer();
    this.#stoppedIntentionally = false;
    this.#channelId = channel.id;

    if (!this.#connection || this.#connection.joinConfig.channelId !== channel.id) {
      this.#connection?.destroy();
      this.#connection = joinVoiceChannel({
        channelId: channel.id,
        guildId: channel.guild.id,
        adapterCreator: channel.guild.voiceAdapterCreator,
        selfDeaf: false,
        selfMute: false,
      });
      this.#connection.on('error', (error) => {
        this.#logger.error({ err: error, channelId: channel.id }, 'Erro na conexão de voz');
      });
      this.#connection.on('stateChange', (oldState, newState) => {
        this.#logger.debug(
          { from: oldState.status, to: newState.status, channelId: channel.id },
          'Estado da conexão de voz alterado',
        );
      });
    }

    await entersState(
      this.#connection,
      VoiceConnectionStatus.Ready,
      this.#settings.connectionTimeoutMs,
    );
    this.#connection.subscribe(this.#player);
  }

  async play(channel: VoiceBasedChannel, station: Station): Promise<void> {
    this.#station = station;
    await this.connect(channel);
    this.#startResource(station);
  }

  stopPlayback(): void {
    this.#stoppedIntentionally = true;
    this.#clearReconnectTimer();
    this.#player.stop(true);
    this.#station = undefined;
    this.#reconnectAttempts = 0;
  }

  disconnect(): void {
    this.stopPlayback();
    this.#connection?.destroy();
    this.#connection = undefined;
    this.#channelId = undefined;
  }

  snapshot(): SessionSnapshot | undefined {
    if (!this.#station || !this.#channelId) return undefined;
    return { station: this.#station, channelId: this.#channelId };
  }

  channelId(): string | undefined {
    return this.#channelId;
  }

  #startResource(station: Station): void {
    const resource = createAudioResource(station.streamUrl, {
      metadata: station,
    });
    this.#player.play(resource);
  }

  #scheduleReconnect(): void {
    if (
      this.#stoppedIntentionally ||
      !this.#station ||
      this.#reconnectTimer ||
      this.#reconnectAttempts >= this.#settings.maxReconnectAttempts
    ) {
      return;
    }
    this.#reconnectAttempts += 1;
    const station = this.#station;
    this.#logger.warn(
      { attempt: this.#reconnectAttempts, stationId: station.id },
      'Tentando reconectar a transmissão',
    );
    this.#reconnectTimer = setTimeout(() => {
      this.#reconnectTimer = undefined;
      this.#startResource(station);
    }, this.#settings.reconnectDelayMs);
  }

  #clearReconnectTimer(): void {
    if (this.#reconnectTimer) clearTimeout(this.#reconnectTimer);
    this.#reconnectTimer = undefined;
  }
}
