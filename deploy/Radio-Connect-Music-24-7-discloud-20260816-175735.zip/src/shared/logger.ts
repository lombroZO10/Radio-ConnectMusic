import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';

import pino from 'pino';

import { config, environment } from '../config/index.js';

const logDirectory = resolve(process.cwd(), 'logs');
mkdirSync(logDirectory, { recursive: true });

export const logger = pino(
  {
    level: environment.LOG_LEVEL ?? config.logging.level,
    base: { service: 'radio-connect-music' },
    redact: {
      paths: ['token', 'DISCORD_TOKEN', '*.token', '*.authorization'],
      censor: '[REDACTED]',
    },
  },
  pino.multistream([
    { stream: pino.destination(1) },
    {
      stream: pino.destination({
        dest: resolve(logDirectory, 'runtime.log'),
        mkdir: true,
        sync: false,
      }),
    },
  ]),
);
