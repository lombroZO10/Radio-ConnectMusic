# Radio Connect Music 24/7 - Wispbyte

Este pacote usa o JavaScript ja compilado em `build/`, portanto nao e necessario
compilar TypeScript na hospedagem.

## Criacao do servidor

- Plano: Free
- Runtime/Docker image: Node.js 24 (ou Node.js 22.12 ou superior)
- Um bot Discord neste servidor

## Variaveis de ambiente

Cadastre em `Startup` > `Server Configuration` / `Environment Variables`:

```text
DISCORD_TOKEN=NOVO_TOKEN_DO_BOT
DISCORD_CLIENT_ID=1288928183420190720
DISCORD_DEV_GUILD_ID=1301004852880478269
LOG_LEVEL=info
```

O token antigo deve ser redefinido no Discord Developer Portal. Nunca envie um
arquivo `.env` para a hospedagem.

## Inicializacao

Use este comando em `Startup Command`:

```sh
npm ci --omit=dev --no-audit --no-fund && npm start
```

Nao preencha `Additional Node.js Packages`: todas as dependencias estao no
`package.json` e suas versoes estao travadas no `package-lock.json`.

## Primeiro teste

1. Inicie o servidor e aguarde `Bot conectado ao Discord` no console.
2. No Discord, execute `/config` e selecione o canal de voz permanente.
3. Execute `/radio tocar` e escolha uma estacao.
4. Se a voz nao conectar, copie o log desde `Estado da conexao de voz alterado`.

O diretorio `data/` nao faz parte do pacote. Ele sera criado pelo bot na
Wispbyte, evitando reutilizar canais salvos na instalacao local ou na Discloud.
